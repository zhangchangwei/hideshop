// production config, it will load in production enviroment
module.exports = {
  workers: 0
};
