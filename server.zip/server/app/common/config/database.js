const mysql = require('think-model-mysql');

module.exports = {
    handle: mysql,
    database: 'hiolabsDB',
    prefix: 'hiolabs_',
    encoding: 'utf8mb4',
    host: '10.100.40.60',
    port: '3306',
    user: 'root',
    password: '123456',
    dateStrings: true
};
//# sourceMappingURL=database.js.map