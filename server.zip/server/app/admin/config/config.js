// default config test
module.exports = {};
//# sourceMappingURL=config.js.map