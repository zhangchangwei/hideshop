const Base = require('./base.js');
const fs = require('fs');
const _ = require('lodash');
const moment = require('moment');
module.exports = class extends Base {};
//# sourceMappingURL=user.js.map